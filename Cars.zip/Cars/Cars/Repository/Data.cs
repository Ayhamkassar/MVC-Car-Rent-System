﻿using Cars.Models;
using System.Runtime.Versioning;
using Microsoft.Data.SqlClient;
using Microsoft.Data;
using Microsoft.AspNetCore.Hosting;
using System.Data;

namespace Cars.Repository
{
    public class Data : IData
    {
        private readonly IConfiguration _configuration;
        private readonly string connectionstring = "";
        private readonly IWebHostEnvironment webhost;
        public Data(IConfiguration _configuration, IWebHostEnvironment webhost)
        {
            this._configuration = _configuration;
            connectionstring = this._configuration.GetConnectionString("Connectionstring");
            this.webhost = webhost;
        }
        public List<string> GetBrand()
        {
            List<string> brand = new List<string>();
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                conn.Open();
                string query = "Select distinct Brand from Cars;";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            brand.Add(reader["Brand"].ToString());
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
            return brand;
        }
        public List<string> GetModel()
        {
            List<string> brand = new List<string>();
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                conn.Open();
                string query = "Select distinct Model from Cars;";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            brand.Add(reader["Model"].ToString());
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
            return brand;
        }
        public List<string> GetDriver()
        { 
            List<string> brand = new List<string>();
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                conn.Open();
                string query = "Select distinct Name from Drivers;";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader =cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            brand.Add(reader["Name"].ToString());
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            { 
                conn.Close();
            }
            return brand;
        }
        public List<Car> GetAllCars()
        { 
            List<Car> cars = new List<Car>();
            Car car;
            SqlConnection sqlConnection = new SqlConnection(connectionstring);
            try
            {
                sqlConnection.Open();
                string query = "Select * from Cars";
                using (SqlCommand cmd = new SqlCommand(query,sqlConnection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            car = new Car();
                            car.ID = int.Parse(reader["ID"].ToString());
                            car.Brand = reader["Brand"].ToString();
                            car.Model = reader["Model"].ToString();
                            car.PassingYear = int.Parse(reader["PassingYear"].ToString());
                            car.Engine = reader["Engine"].ToString();
                            car.FuelType = reader["FuelType"].ToString();
                            car.ImagePath = reader["ImagePath"].ToString();
                            car.CarNumber = reader["CarNumber"].ToString();
                            car.SeatingCapacity = reader["SeatingCapacity"].ToString();
                            cars.Add(car);
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally 
            {
                sqlConnection.Close();
            }
            return cars;
        }
        public List<Maintenance> GetMaintenance()
        {
            List<Maintenance> drivers = new List<Maintenance>();
            Maintenance driver;
            SqlConnection sqlConnection = new SqlConnection(connectionstring);
            try
            {
                sqlConnection.Open();
                string query = "Select * from Maintenance";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            driver = new Maintenance();
                            driver.ID = int.Parse(reader["ID"].ToString());
                            driver.Cost = int.Parse(reader["Address"].ToString());
                            driver.Notes = reader["MobileNo"].ToString();
                            driver.MaintenanceDate = DateTime.Parse(reader["Age"].ToString());
                            driver.MaintenanceType = reader["Experince"].ToString();
                            driver.CarID = int.Parse(reader["ImagePath"].ToString());
                            drivers.Add(driver);
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
            return drivers;
        }
        public List<Payment> GetPayment()
        {
            List<Payment> payments = new List<Payment>();
            Payment payment;
            SqlConnection sqlConnection = new SqlConnection(connectionstring);
            try
            {
                sqlConnection.Open();
                string query = "Select * from Maintenance";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            payment = new Payment();
                            payment.ID = int.Parse(reader["ID"].ToString());
                            payment.CustomerName = reader["Name"].ToString();
                            payment.Car = reader["Car"].ToString();
                            payment.Price = int.Parse(reader["Price"].ToString());
                            payment.Date = DateTime.Parse(reader["Date"].ToString());
                            payments.Add(payment);
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
            return payments;
        }
        public List<Driver> GetAllDrivers()
        {
            List<Driver> drivers = new List<Driver>();
            Driver driver;
            SqlConnection sqlConnection = new SqlConnection(connectionstring);
            try
            {
                sqlConnection.Open();
                string query = "Select * from Drivers";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            driver = new Driver();
                            driver.ID = int.Parse(reader["ID"].ToString());
                            driver.Address = reader["Address"].ToString();
                            driver.MobileNo = int.Parse(reader["MobileNo"].ToString());
                            driver.Age = reader["Age"].ToString();
                            driver.Experince = reader["Experince"].ToString();
                            driver.ImagePath = reader["ImagePath"].ToString();
                            drivers.Add(driver);
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
            return drivers;
        }
        public List<Rent> GetAllBooks()
        {
            List<Rent> books = new List<Rent>();
            Rent book;
            SqlConnection sqlConnection = new SqlConnection(connectionstring);
            try
            {
                sqlConnection.Open();
                string query = "Select * from Rents";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            book = new Rent();
                            book.ID = int.Parse(reader["ID"].ToString());
                            book.PickUp = reader["PickUp"].ToString();
                            book.DropOff = reader["DropOff"].ToString();
                            book.PickUpDate = DateTime.Parse(reader["PickUpDate"].ToString());
                            book.TotalRun = int.Parse(reader["TotalRun"].ToString());
                            book.Rate = int.Parse(reader["Rate"].ToString());
                            book.TotalAmount = int.Parse(reader["TotalAmount"].ToString());
                            book.Brand = reader["Brand"].ToString();
                            book.Model = reader["Model"].ToString();
                            book.CustomerContact = reader["CustomerContactNo"].ToString();
                            book.DriverId = int.Parse(reader["DriverId"].ToString());
                            book.CustomerName = reader["CustomerName"].ToString();
                            books.Add(book);
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                sqlConnection.Close();
            }
            return books;
        }
        public bool AddNewCar(Car newcar)
        {
            bool IsSaved=false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string state = conn.State.ToString();
                newcar.ImagePath = SaveImage(newcar.CarImage,"carsimages");
                string query = String.Format("INSERT into Cars (Brand,Model,PassingYear,CarNumber,Engine,FuelType,ImagePath,SeatingCapacity)" +
                    " values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')",
                    newcar.Brand,newcar.Model,newcar.PassingYear,newcar.CarNumber,newcar.Engine,
                    newcar.FuelType,newcar.ImagePath,newcar.SeatingCapacity);
                IsSaved = SaveData(query);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsSaved;
        }
        public bool UpdateCar(Car updatedCar)
        {
            bool IsUpdated = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"UPDATE Cars SET Brand = '{updatedCar.Brand}', Model = '{updatedCar.Model}', PassingYear = {updatedCar.PassingYear}, CarNumber = '{updatedCar.CarNumber}', Engine = '{updatedCar.Engine}', FuelType = '{updatedCar.FuelType}', ImagePath = '{updatedCar.ImagePath}', SeatingCapacity = '{updatedCar.SeatingCapacity}' WHERE ID = {updatedCar.ID}";
                IsUpdated = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsUpdated;
        }
        public bool DeleteCar(int carId)
        {
            bool IsDeleted = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"DELETE FROM Cars WHERE ID = {carId}";
                IsDeleted = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsDeleted;
        }

        public bool AddNewPayment(Payment newcar)
        {
            bool IsSaved = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string state = conn.State.ToString();
                string query = String.Format("INSERT into Payments (Car,CustomerName,Date,Price)" +
                    " values('{0}','{1}','{2}','{3}')",
                    newcar.Car, newcar.CustomerName, newcar.Date, newcar.Price);
                IsSaved = SaveData(query);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsSaved;
        }
        public bool UpdatePayment(Payment updatedPayment)
        {
            bool IsUpdated = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"UPDATE Payments SET CustomerName = '{updatedPayment.CustomerName}', Price = '{updatedPayment.Price}', Date = {updatedPayment.Date}, Car = '{updatedPayment.Car}' WHERE ID = {updatedPayment.ID}";
                IsUpdated = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsUpdated;
        }
        public bool DeletePayment(int carId)
        {
            bool IsDeleted = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"DELETE FROM Payments WHERE ID = {carId}";
                IsDeleted = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsDeleted;
        }



        public bool AddNewBooking(Rent newrent)
        {
            bool IsSaved = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                newrent.TotalAmount = newrent.TotalRun = newrent.Rate;
                string query = String.Format("INSERT into Rents (PickUp,DropOff,PickUpDate,DropOffDate,TotalRun,Rate,TotalAmount,Brand,Model,DriverId,CustomerName,CustomerContactNo)" +
                    " values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}')",
                    newrent.PickUp, newrent.DropOff, newrent.PickUpDate, newrent.DropOffDate, newrent.TotalRun,
                    newrent.Rate, newrent.TotalAmount, newrent.Brand,newrent.Model,newrent.DriverId,newrent.CustomerName,newrent.CustomerContact);
                IsSaved = SaveData(query);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsSaved;
        }
        public bool UpdateRent(Rent updatedRent)
        {
            bool IsUpdated = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"UPDATE Rents SET PickUp = '{updatedRent.PickUp}', DropOff = '{updatedRent.DropOff}', PickUpDate = '{updatedRent.PickUpDate}', DropOffDate = '{updatedRent.DropOffDate}', TotalRun = {updatedRent.TotalRun}, Rate = {updatedRent.Rate}, TotalAmount = {updatedRent.TotalAmount}, Brand = '{updatedRent.Brand}', Model = '{updatedRent.Model}', DriverId = {updatedRent.DriverId}, CustomerName = '{updatedRent.CustomerName}', CustomerContactNo = '{updatedRent.CustomerContact}' WHERE ID = {updatedRent.ID}";
                IsUpdated = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsUpdated;
        }
        public bool DeleteRent(int rentId)
        {
            bool IsDeleted = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"DELETE FROM Rents WHERE ID = {rentId}";
                IsDeleted = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsDeleted;
        }

        public bool AddNewDriver(Driver newdriver)
        {
            bool IsSaved = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string state = conn.State.ToString();
                newdriver.ImagePath = SaveImage(newdriver.DriverImage, "driversimages");
                string query = String.Format("INSERT into Drivers (Name,Address,MobileNo,Age,Experince,ImagePath)" +
                    " values('{0}','{1}','{2}','{3}','{4}','{5}')",
                    newdriver.Name,newdriver.Address, newdriver.MobileNo, newdriver.Age, newdriver.Experince,
                    newdriver.ImagePath);
                IsSaved = SaveData(query);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsSaved;
        }
        public bool DeleteDriver(int driverId)
        {
            bool IsDeleted = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"DELETE FROM Drivers WHERE ID = {driverId}";
                IsDeleted = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsDeleted;
        }
        public bool UpdateDriver(Driver updatedDriver)
        {
            bool IsUpdated = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"UPDATE Drivers SET Name = '{updatedDriver.Name}', Address = '{updatedDriver.Address}', MobileNo = {updatedDriver.MobileNo}, Age = '{updatedDriver.Age}', Experince = '{updatedDriver.Experince}', ImagePath = '{updatedDriver.ImagePath}' WHERE ID = {updatedDriver.ID}";
                IsUpdated = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return IsUpdated;
        }

        private string SaveImage(IFormFile file , string foldername)
        {
            string imagePath = "";
            try
            {
                string uploadfolder =Path.Combine(webhost.WebRootPath,"images/" + foldername);
                imagePath = Guid.NewGuid().ToString()+"_"+file.FileName;
                string filePath = Path.Combine(uploadfolder, imagePath);
                using (FileStream fileStream = new FileStream(filePath,FileMode.OpenOrCreate))
                {
                    file.CopyTo(fileStream);
                }
            }
            catch (Exception)
            {

                throw;
            }
            return imagePath;
        }
        private bool SaveData(string query)
        {
            SqlConnection conn = new SqlConnection(connectionstring);
            bool IsSaved = false;
            try
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                { 
                    cmd.ExecuteNonQuery();
                    IsSaved = true;
                }
            }
            catch (Exception)
            {

                throw;
            }
            return IsSaved;
        }
        public List<Maintenance> GetAllMaintenance()
        {
            List<Maintenance> maintenanceRecords = new List<Maintenance>();
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                conn.Open();
                string query = "SELECT * FROM Maintenance";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Maintenance maintenance = new Maintenance
                            {
                                ID = int.Parse(reader["ID"].ToString()),
                                CarID = int.Parse(reader["CarID"].ToString()),
                                MaintenanceDate = DateTime.Parse(reader["MaintenanceDate"].ToString()),
                                Cost = decimal.Parse(reader["Cost"].ToString())
                            };
                            maintenanceRecords.Add(maintenance);
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return maintenanceRecords;
        }
        public bool AddMaintenance(Maintenance maintenance)
        {
            bool isSaved = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = String.Format("INSERT INTO Maintenance (CarID, MaintenanceDate, Details, Cost) " +
                    "VALUES ('{0}', '{1}', '{2}', '{3}')",
                    maintenance.CarID, maintenance.MaintenanceDate, maintenance.Cost);
                isSaved = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return isSaved;
        }
        public bool UpdateMaintenance(Maintenance updatedMaintenance)
        {
            bool isUpdated = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"UPDATE Maintenance SET CarID = {updatedMaintenance.CarID}, " +
                               $"MaintenanceDate = '{updatedMaintenance.MaintenanceDate}', " +
                               $"Cost = {updatedMaintenance.Cost} " +
                               $"WHERE ID = {updatedMaintenance.ID}";
                isUpdated = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return isUpdated;
        }
        public bool DeleteMaintenance(int maintenanceId)
        {
            bool isDeleted = false;
            SqlConnection conn = new SqlConnection(connectionstring);
            try
            {
                string query = $"DELETE FROM Maintenance WHERE ID = {maintenanceId}";
                isDeleted = SaveData(query);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }
            return isDeleted;
        }

    }
}
