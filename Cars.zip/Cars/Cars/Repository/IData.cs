﻿using Cars.Models;
namespace Cars.Repository
{
    public interface IData
    {
        bool AddNewCar(Car newcar);
        bool UpdateCar(Car updatedcar);
        bool DeleteCar(int deletedcar);
        bool AddNewDriver(Driver newdriver);
        bool UpdateDriver(Driver updateddriver);
        bool DeleteDriver(int deleteddriver);
        bool AddNewPayment(Payment newdriver);
        bool UpdatePayment(Payment updateddriver);
        bool DeletePayment(int deleteddriver);
        bool AddNewBooking(Rent rent);
        bool UpdateRent(Rent rent);
        bool DeleteRent(int deletedbook);
        bool AddMaintenance(Maintenance maintenance);
        bool UpdateMaintenance(Maintenance maintenance);
        bool DeleteMaintenance(int maintenance);
        List<Car> GetAllCars();
        List<Driver> GetAllDrivers();
        List<Rent> GetAllBooks();
        List<string> GetBrand();
        List<Payment> GetPayment();
        List<string> GetModel();
        List<string> GetDriver();
        List<Maintenance> GetAllMaintenance();
    }
}
