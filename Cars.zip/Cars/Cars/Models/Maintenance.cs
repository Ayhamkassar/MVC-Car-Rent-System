﻿using System.ComponentModel.DataAnnotations;

namespace Cars.Models
{
    public class Maintenance
    {
        public int ID { get; set; }
        public int CarID { get; set; }
        [Required]
        public DateTime MaintenanceDate { get; set; }
        [Required]
        public string MaintenanceType { get; set; } 
        [Required]
        public decimal Cost { get; set; } 
        [Required]
        public virtual Car Car { get; set; }
        [Required]
        public string Notes { get; set; } 
    }
}
