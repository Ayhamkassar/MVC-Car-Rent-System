﻿using System.ComponentModel.DataAnnotations;

namespace Cars.Models
{
    public class Car
    {
        public int ID { get; set; }
        [Required]
        public string? Brand { get; set; }
        [Required]
        public string? Model { get; set; }
        [Required]
        public int PassingYear { get; set; }
        [Required]
        public string? CarNumber { get; set; }
        [Required]
        public string? Engine { get; set; }
        [Required]
        public string? FuelType { get; set; }
        [Required]
        public string? SeatingCapacity { get; set; }
        [Required]
        public IFormFile CarImage { get; set; }
        public string? ImagePath { get; set; }
    }
}
