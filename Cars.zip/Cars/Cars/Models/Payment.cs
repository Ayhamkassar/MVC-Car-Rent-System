﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Cars.Models
{
    public class Payment
    {
        public int ID { get; set; }
        [Required]
        public string? CustomerName { get; set; }
        [Required]
        public int Price { get; set; }
        [Required]
        public DateTime Date { get; set; }
        [Required]
        public string? Car { get; set; }
    }
}
