﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Cars.Models
{
    public class Driver
    {
        public int ID { get; set; }
        [Required]
        public string? Name { get; set; }
        [Required]
        public string? Address { get; set; }
        [Required]
        public int MobileNo { get; set; }
        [Required]
        public string? Age { get; set; }
        [Required]
        public string? Experince { get; set; }
        [Required]
        public IFormFile DriverImage { get; set; }
        public string? ImagePath { get; set; }
    }
}
