﻿using Microsoft.AspNetCore.Mvc;
using Cars.Models;
using Cars.Repository;
using System.Collections.Generic;
using System.Linq;

namespace Cars.Controllers
{
    public class RentController : Controller
    {
        private readonly IData data;
        public RentController(IData _data)
        {
            data = _data;
        }

        public IActionResult Index()
        {
            var list = data.GetAllBooks();
            return View(list);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Rent rent)
        {
            if (!ModelState.IsValid)
                return View(rent);

            bool IsSaved = data.AddNewBooking(rent);
            ViewBag.IsSaved = IsSaved;
            ModelState.Clear();
            return View();
        }

        [HttpGet]
        public IActionResult GetBrand()
        {
            var list = data.GetBrand();
            return Json(list);
        }

        public IActionResult GetModel()
        {
            var list = data.GetModel();
            return Json(list);
        }

        public IActionResult GetDriver()
        {
            var list = data.GetDriver();
            return Json(list);
        }

        public IActionResult Edit(int id)
        {
            var rent = data.GetAllBooks().FirstOrDefault(r => r.ID == id);
            if (rent == null)
            {
                return NotFound();
            }
            return View(rent);
        }

        [HttpPost]
        public IActionResult Edit(Rent updatedRent)
        {
            if (!ModelState.IsValid)
            {
                return View(updatedRent);
            }

            bool isUpdated = data.UpdateRent(updatedRent);
            if (isUpdated)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Error = "Failed to update booking.";
            return View(updatedRent);
        }

        public IActionResult Delete(int id)
        {
            var rent = data.GetAllBooks().FirstOrDefault(r => r.ID == id);
            if (rent == null)
            {
                return NotFound();
            }
            return View(rent);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult ConfirmDelete(int id)
        {
            bool isDeleted = data.DeleteRent(id);
            if (isDeleted)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Error = "Failed to delete booking.";
            return View();
        }
    }
}
