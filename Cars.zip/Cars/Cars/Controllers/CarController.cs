﻿using Microsoft.AspNetCore.Mvc;
using Cars.Models;
using Cars.Repository;

namespace Cars.Controllers
{
    public class CarController : Controller
    {
        private readonly IData data;
        public CarController(IData _data)
        {
            data = _data;
        }

        public IActionResult Index()
        {
            var list = data.GetAllCars();
            return View(list);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Car newcar)
        {
            if (!ModelState.IsValid)
                return View(newcar);

            bool IsSaved = data.AddNewCar(newcar);
            ViewBag.IsSaved = IsSaved;
            ModelState.Clear();
            return View();
        }

        public IActionResult Edit(int id)
        {
            var car = data.GetAllCars().FirstOrDefault(c => c.ID == id);
            if (car == null)
            {
                return NotFound();
            }
            return View(car);
        }

        [HttpPost]
        public IActionResult Edit(Car updatedCar)
        {
            if (!ModelState.IsValid)
            {
                return View(updatedCar);
            }

            bool isUpdated = data.UpdateCar(updatedCar);
            if (isUpdated)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Error = "Failed to update car.";
            return View(updatedCar);
        }
        
        public IActionResult Delete(int id)
        {
            var car = data.GetAllCars().FirstOrDefault(c => c.ID == id);
            if (car == null)
            {
                return NotFound();
            }
            return View(car);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult ConfirmDelete(int id)
        {
            bool isDeleted = data.DeleteCar(id);
            if (isDeleted)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Error = "Failed to delete car.";
            return View();
        }
    }
}
