﻿using Cars.Models;
using Cars.Repository;
using Microsoft.AspNetCore.Mvc;

public class MaintenanceController : Controller
{
    private readonly IData data;
    public MaintenanceController(IData _data)
    {
        data = _data;
    }

    public IActionResult Index()
    {
        var maintenanceList = data.GetAllMaintenance();
        return View(maintenanceList);
    }


    public IActionResult Add()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Add(Maintenance newMaintenance)
    {
        if (!ModelState.IsValid)
            return View(newMaintenance);

        bool isSaved = data.AddMaintenance(newMaintenance);
        ViewBag.IsSaved = isSaved;
        ModelState.Clear();
        return View();
    }

    public IActionResult Edit(int id)
    {
        var maintenance = data.GetAllMaintenance().FirstOrDefault(m => m.ID == id);
        if (maintenance == null)
        {
            return NotFound();
        }
        return View(maintenance);
    }

    [HttpPost]
    public IActionResult Edit(Maintenance updatedMaintenance)
    {
        if (!ModelState.IsValid)
        {
            return View(updatedMaintenance);
        }

        bool isUpdated = data.UpdateMaintenance(updatedMaintenance);
        if (isUpdated)
        {
            return RedirectToAction("Index");
        }

        ViewBag.Error = "Failed to update maintenance record.";
        return View(updatedMaintenance);
    }

    public IActionResult Delete(int id)
    {
        var maintenance = data.GetAllMaintenance().FirstOrDefault(m => m.ID == id);
        if (maintenance == null)
        {
            return NotFound();
        }
        return View(maintenance);
    }

    [HttpPost, ActionName("Delete")]
    public IActionResult ConfirmDelete(int id)
    {
        bool isDeleted = data.DeleteMaintenance(id);
        if (isDeleted)
        {
            return RedirectToAction("Index");
        }

        ViewBag.Error = "Failed to delete maintenance record.";
        return View();
    }
}
