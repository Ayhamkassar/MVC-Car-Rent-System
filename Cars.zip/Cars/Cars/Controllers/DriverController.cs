﻿using Microsoft.AspNetCore.Mvc;
using Cars.Models;
using Cars.Repository;

namespace Cars.Controllers
{
    public class DriverController : Controller
    {
        private readonly IData data;
        public DriverController(IData _data)
        {
            data = _data;
        }

        public IActionResult Index()
        {
            var list = data.GetAllDrivers();
            return View(list);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Driver newdriver)
        {
            if (!ModelState.IsValid)
                return View(newdriver);

            bool IsSaved = data.AddNewDriver(newdriver);
            ViewBag.IsSaved = IsSaved;
            ModelState.Clear();
            return View();
        }

        public IActionResult Edit(int id)
        {
            var driver = data.GetAllDrivers().FirstOrDefault(d => d.ID == id);
            if (driver == null)
            {
                return NotFound();
            }
            return View(driver);
        }

        [HttpPost]
        public IActionResult Edit(Driver updatedDriver)
        {
            if (!ModelState.IsValid)
            {
                return View(updatedDriver);
            }

            bool isUpdated = data.UpdateDriver(updatedDriver);
            if (isUpdated)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Error = "Failed to update driver.";
            return View(updatedDriver);
        }

        public IActionResult Delete(int id)
        {
            var driver = data.GetAllDrivers().FirstOrDefault(d => d.ID == id);
            if (driver == null)
            {
                return NotFound();
            }
            return View(driver);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult ConfirmDelete(int id)
        {
            bool isDeleted = data.DeleteDriver(id);
            if (isDeleted)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Error = "Failed to delete driver.";
            return View();
        }
    }
}
