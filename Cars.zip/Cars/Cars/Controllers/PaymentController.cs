﻿using Microsoft.AspNetCore.Mvc;
using Cars.Models;
using Cars.Repository;

namespace Cars.Controllers
{
    public class PaymentController : Controller
    {
        private readonly IData data;
        public PaymentController(IData _data)
        {
            data = _data;
        }

        public IActionResult Index()
        {
            var list = data.GetPayment();
            return View(list);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Payment newpayment)
        {
            if (!ModelState.IsValid)
                return View(newpayment);

            bool IsSaved = data.AddNewPayment(newpayment);
            ViewBag.IsSaved = IsSaved;
            ModelState.Clear();
            return View();
        }

        public IActionResult Edit(int id)
        {
            var car = data.GetPayment().FirstOrDefault(c => c.ID == id);
            if (car == null)
            {
                return NotFound();
            }
            return View(car);
        }

        [HttpPost]
        public IActionResult Edit(Payment updatedpayment)
        {
            if (!ModelState.IsValid)
            {
                return View(updatedpayment);
            }

            bool isUpdated = data.UpdatePayment(updatedpayment);
            if (isUpdated)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Error = "Failed to update Payment.";
            return View(updatedpayment);
        }

        public IActionResult Delete(int id)
        {
            var payment = data.GetPayment().FirstOrDefault(c => c.ID == id);
            if (payment == null)
            {
                return NotFound();
            }
            return View(payment);
        }
    }
}
